import { atom } from "jotai";

export const favouritesAtom = atom((async ()=>{
    const results = [];
    return results;
})());

export const searchHistoryAtom = atom((async ()=>{
    const results = [];
    return results;
})());

