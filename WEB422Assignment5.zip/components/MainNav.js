import {Container, Form, Nav, Navbar, Button, NavDropdown} from 'react-bootstrap';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { useState } from 'react';
import { searchHistoryAtom } from '@/store';
import { useAtom } from 'jotai';

export default function MainNav() {
    const router = useRouter();
    const [searchField, setSearchField] = useState("");
    const [isExpanded, setIsExpanded] = useState(false);
    const [searchHistory, setSearchHistory] = useAtom(searchHistoryAtom);


    function handleSubmit(e){
        let queryString = `title=true&q=${searchField}`;      
        e.preventDefault();
        setIsExpanded(false);
        setSearchHistory([...searchHistory, queryString]); 
        router.push(`/artwork?title=true&q=${searchField}`);
    }
    
    return (
      <>
            <Navbar expand="lg" className="fixed-top navbar-dark bg-primary" expanded={isExpanded}>
                <Container>
                    <Navbar.Brand>Olutoyosi Kuti</Navbar.Brand>
                    <Navbar.Toggle aria-controls="navbarScroll" onClick={()=> setIsExpanded(!isExpanded)} />
                    <Navbar.Collapse id="navbarScroll">
                        <Nav
                            className="me-auto my-2 my-lg-0"
                            style={{ maxHeight: '100px' }}
                            navbarScroll
                        >
                            <Link href="/" passHref legacyBehavior><Nav.Link onClick={()=>setIsExpanded(false)} active={router.pathname === "/"}>Home</Nav.Link></Link>
                            <Link href="/search" passHref legacyBehavior><Nav.Link onClick={()=>setIsExpanded(false)} active={router.pathname === "/search"}>Advanced Search</Nav.Link></Link>
                        </Nav> &nbsp;
                        <Form className="d-flex" onSubmit={handleSubmit}>
                            <Form.Control
                            type="search"
                            placeholder="Search"
                            className="me-2"
                            aria-label="Search"
                            value={searchField}
                            onChange={e=>{setSearchField(e.target.value)}}
                            />
                            <Button variant="light" type="submit">Search</Button>
                        </Form>&nbsp;
                        <Nav>
                            <NavDropdown title="User Name" id="basic-nav-dropdown">
                                <Link href="/favourites" passHref legacyBehaviour><NavDropdown.Item href="/favourites" onClick={()=>setIsExpanded(false)} active={router.pathname === "/favourites"}>Favourites</NavDropdown.Item></Link>
                                <Link href="/history" passHref legacyBehaviour><NavDropdown.Item href="/history" onClick={()=>setIsExpanded(false)}  active={router.pathname === "/history"}>Search History</NavDropdown.Item></Link>
                            </NavDropdown>
                        </Nav>
                    </Navbar.Collapse>
                </Container>
            </Navbar>
            <br /><br />
        </>
    );
}


