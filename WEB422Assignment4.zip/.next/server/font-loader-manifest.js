self.__FONT_LOADER_MANIFEST={
  "pages": {},
  "app": {},
  "appUsingSizeAdjust": false,
  "pagesUsingSizeAdjust": false
}